import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { AIEvaluation } from '../types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// 下载录音文件到设备
export const downloadRecording = (blob: Blob, fileName: string = 'fabe_practice_recording') => {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${fileName}_${new Date().toISOString().slice(0, 10)}.wav`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

// 格式化录音时长
export const formatDuration = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

// 模拟AI评价生成
// 现在这个函数会接收产品和客户信息，生成更加个性化的评价
export const generateAIEvaluation = (productName?: string, customer?: {
  personality: string;
  needs: string[];
  concerns: string[];
}): AIEvaluation => {
  // 随机决定是否存在明显问题（念文档、背书、逻辑混乱等）
  // 20%的概率存在严重问题，30%的概率存在中等问题，50%的概率表现正常
  const issueType = Math.random();
  
  // 基础评分参数
  let baseScore = 3; // 基础分
  let isReadingScript = false; // 是否直接念文档
  let isReciting = false; // 是否像背书
  let isConfused = false; // 逻辑是否混乱
  let isNotMatchingCustomer = false; // 是否不符合客户需求
  
  // 根据问题类型调整基础分和问题标记
  if (issueType < 0.2) {
    // 20%概率存在严重问题，评分较低
    baseScore = 1;
    // 随机选择1-3个严重问题
    const issuesCount = Math.floor(Math.random() * 3) + 1;
    const issues: string[] = [];
    
    // 随机选择问题类型
    if (issuesCount >= 1) issues.push('reading');
    if (issuesCount >= 2) issues.push('reciting');
    if (issuesCount >= 3) issues.push('confused');
    
    // 应用问题标记
    isReadingScript = issues.includes('reading');
    isReciting = issues.includes('reciting');
    isConfused = issues.includes('confused');
  } else if (issueType < 0.5) {
    // 30%概率存在中等问题，评分中等
    baseScore = 2;
    // 随机选择1-2个中等问题
    const issueRand = Math.random();
    if (issueRand < 0.3) isConfused = true;
    else if (issueRand < 0.6) isReciting = true;
    else if (issueRand < 0.85) isReadingScript = true;
    else isNotMatchingCustomer = true;
  }
  
  // 根据客户类型增加特定问题的可能性
  // 创建一个变量来记录是否需要对说服力分数进行调整
  let persuasionAdjustment = 0;
  
  if (customer && Math.random() < 0.3) {
    switch(customer.personality) {
      case '谨慎型':
        // 谨慎型客户更容易对说服力不足有意见
        if (baseScore <= 3) persuasionAdjustment -= 0.5;
        break;
      case '冲动型':
        // 冲动型客户更容易觉得逻辑混乱
        if (Math.random() < 0.4) isConfused = true;
        break;
      case '理智型':
        // 理智型客户更容易发现是否匹配需求
        if (Math.random() < 0.4) isNotMatchingCustomer = true;
        break;
      case '情感型':
        // 情感型客户更容易察觉是否缺乏自信
        if (Math.random() < 0.4) isReciting = true;
        break;
    }
  }
  
  // 生成各维度评分，根据基础分和问题情况进行调整
  const fabeStructure = Math.min(5, Math.max(1, Math.floor(Math.random() * 2) + baseScore + (isConfused ? -1 : 0)));
  const languageFluency = Math.min(5, Math.max(1, Math.floor(Math.random() * 2) + baseScore + (isReadingScript || isReciting ? -1 : 0)));
  const customerMatch = Math.min(5, Math.max(1, Math.floor(Math.random() * 2) + baseScore + (isNotMatchingCustomer ? -1 : 0)));
  const persuasion = Math.min(5, Math.max(1, Math.floor(Math.random() * 2) + baseScore + persuasionAdjustment + (isReadingScript || isReciting || isConfused ? -1 : 0)));
  const confidence = Math.min(5, Math.max(1, Math.floor(Math.random() * 2) + baseScore + (isReadingScript || isReciting ? -1 : 0)));
  
  // 计算总评分
  const overallScore = (fabeStructure + languageFluency + customerMatch + persuasion + confidence) / 5;
  
  // 根据产品和客户类型生成更具针对性的建议和优点
  const getProductSpecificSuggestions = () => {
    const suggestions: string[] = [];
    
    if (productName) {
      const productBased = [
        `在介绍${productName}时，可以更突出其核心特征如何满足客户需求`,
        `建议您针对${productName}的独特优势进行更详细的解释`,
        `您可以尝试将${productName}与客户的实际使用场景结合起来说明`,
        `在介绍${productName}时，可以加入更多具体的使用案例`
      ];
      
      // 随机选择1个与产品相关的建议
      if (Math.random() < 0.5) {
        const randomIndex = Math.floor(Math.random() * productBased.length);
        suggestions.push(productBased[randomIndex]);
      }
    }
    
    if (customer) {
      // 根据客户类型生成建议
      const personalityBased = {
        '谨慎型': [
          '对于谨慎型客户，建议您提供更多数据和证据来支持您的产品介绍',
          '谨慎型客户更关注风险，您可以重点说明产品如何解决他们的顾虑',
          '可以增加一些实际用户反馈或专家推荐来增强可信度'
        ],
        '冲动型': [
          '冲动型客户喜欢直接的价值呈现，建议您更简洁明了地突出核心卖点',
          '可以增加一些紧迫感，比如产品的独特性或限时优惠',
          '用更有感染力的语言和情感化的描述来打动这类客户'
        ],
        '理智型': [
          '理智型客户注重逻辑和事实，建议您按照清晰的结构进行介绍',
          '可以提供更多技术细节和对比分析',
          '针对客户提出的具体需求，给出精确的解决方案'
        ],
        '情感型': [
          '情感型客户更看重个人感受和体验，建议您分享更多使用体验和感受',
          '可以强调产品如何提升生活品质或带来愉悦感',
          '用更亲切、温暖的语气进行沟通'
        ]
      };
      
      // 根据客户需求生成建议
      if (customer.needs && customer.needs.length > 0 && Math.random() < 0.7) {
        const randomNeedIndex = Math.floor(Math.random() * customer.needs.length);
        suggestions.push(`您可以更深入地针对客户的${customer.needs[randomNeedIndex]}需求进行说明`);
      }
      
      // 根据客户顾虑生成建议
      if (customer.concerns && customer.concerns.length > 0 && Math.random() < 0.7) {
        const randomConcernIndex = Math.floor(Math.random() * customer.concerns.length);
        suggestions.push(`建议您主动回应客户可能对${customer.concerns[randomConcernIndex]}的顾虑`);
      }
      
      // 添加基于客户性格的建议
      if (personalityBased[customer.personality as keyof typeof personalityBased] && Math.random() < 0.7) {
        const personalitySuggestions = personalityBased[customer.personality as keyof typeof personalityBased];
        const randomIndex = Math.floor(Math.random() * personalitySuggestions.length);
        suggestions.push(personalitySuggestions[randomIndex]);
      }
    }
    
    return suggestions;
  };
  
  // 预设的通用建议和优点列表（扩充了更多内容）
  const genericSuggestions = [
    "可以进一步强调产品如何满足客户的具体需求",
    "建议在介绍产品优势时加入更多具体案例",
    "可以尝试使用更自然的语调，增强亲和力",
    "建议在结束时加入明确的行动号召",
    "注意控制语速，确保重点内容清晰传达",
    "可以更深入地了解客户的顾虑并针对性回应",
    "避免直接背诵产品说明，尝试用自己的语言表达",
    "注意与客户的互动，避免单向灌输",
    "加强逻辑连贯性，确保内容有条理地展开",
    "提升语言的流畅度，减少卡顿和重复",
    "表现出更多的自信，避免听起来像在背诵",
    "可以增加一些提问，引导客户参与到对话中来",
    "注意观察客户的反应，及时调整您的推销策略",
    "建议使用更简洁明了的语言，避免专业术语过多",
    "在介绍产品时，可以结合客户的实际使用场景",
    "尝试用故事化的方式来介绍产品，增加吸引力",
    "注意保持微笑和积极的肢体语言",
    "建议在开始时建立良好的关系，再进行产品介绍",
    "可以先了解客户的预算范围，再推荐合适的产品",
    "注意倾听客户的需求和反馈，而不是急于推销"
  ];
  
  const genericStrengths = [
    "FABE结构基本完整，思路清晰",
    "语言表达流畅，用词准确",
    "能够针对客户需求调整话术",
    "声音洪亮，充满自信",
    "能够有效传达产品的核心价值",
    "逻辑连贯，层次分明",
    "能够自然地表达产品信息，不像是在背诵",
    "与客户需求的匹配度较高",
    "说服力强，能够打动听众",
    "自信度高，表现从容",
    "对产品的了解较为全面",
    "能够清晰地解释产品的优势和利益",
    "语气亲切，具有良好的亲和力",
    "能够灵活应对客户可能的疑问",
    "时间控制得当，重点突出",
    "能够有效地建立信任关系",
    "表达简洁明了，避免冗长",
    "能够结合实际案例进行说明",
    "能够强调产品的独特卖点",
    "能够关注客户的反馈并及时调整"
  ];
  
  // 根据问题类型添加特定的建议
  const specificSuggestions: string[] = [];
  if (isReadingScript) {
    const readingScriptSuggestions = [
      "检测到您可能在直接念诵文档内容，建议用更自然的方式表达，体现理解和思考过程。",
      "您的表达听起来像是在阅读事先准备的材料，尝试用自己的语言重新组织内容会更有说服力。",
      "建议您将产品信息内化后再表达，避免机械地背诵。"
    ];
    const randomIndex = Math.floor(Math.random() * readingScriptSuggestions.length);
    specificSuggestions.push(readingScriptSuggestions[randomIndex]);
  }
  if (isReciting) {
    const recitingSuggestions = [
      "您的表达听起来有些生硬，像是在背书，建议增加一些口语化的表达和个人理解。",
      "尝试用更自然的语速和语调，让推销过程更像是一次对话而非演讲。",
      "可以加入一些您自己对产品的真实感受，增加可信度。"
    ];
    const randomIndex = Math.floor(Math.random() * recitingSuggestions.length);
    specificSuggestions.push(recitingSuggestions[randomIndex]);
  }
  if (isConfused) {
    const confusedSuggestions = [
      "您的推销逻辑有些混乱，建议按照FABE结构清晰地组织内容，先讲特征，再讲优势，然后是利益，最后提供证据。",
      "可以先列出您要介绍的关键点，然后按照逻辑顺序逐一说明。",
      "建议在开始前先理清思路，明确每个部分要传达的核心信息。"
    ];
    const randomIndex = Math.floor(Math.random() * confusedSuggestions.length);
    specificSuggestions.push(confusedSuggestions[randomIndex]);
  }
  if (isNotMatchingCustomer) {
    const notMatchingSuggestions = [
      "您的推销内容与客户的需求匹配度不够，建议先了解客户的具体需求，再针对性地介绍产品。",
      "可以多询问客户的需求和偏好，然后根据这些信息调整您的推销重点。",
      "建议重点关注客户提到的需求点，说明产品如何满足这些需求。"
    ];
    const randomIndex = Math.floor(Math.random() * notMatchingSuggestions.length);
    specificSuggestions.push(notMatchingSuggestions[randomIndex]);
  }
  
  // 获取产品和客户特定的建议
  const productCustomerSuggestions = getProductSpecificSuggestions();
  
  // 随机选择建议和优点
  const getRandomItems = (pool: string[], count: number) => {
    const shuffled = [...pool].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  };
  
  // 合并所有建议
  const totalSuggestionsNeeded = 4; // 增加建议数量
  let remainingSlots = totalSuggestionsNeeded - specificSuggestions.length - productCustomerSuggestions.length;
  
  // 确保至少有一个通用建议
  let allSuggestions = [...specificSuggestions, ...productCustomerSuggestions];
  
  // 如果还有剩余槽位，从通用建议池中补充
  if (remainingSlots > 0) {
    const randomGenericSuggestions = getRandomItems(genericSuggestions, remainingSlots);
    allSuggestions = [...allSuggestions, ...randomGenericSuggestions];
  }
  
  // 根据评分决定是否添加优点以及优点数量
  let allStrengths: string[] = [];
  if (overallScore >= 2.5) {
    const strengthsCount = overallScore >= 4 ? 3 : 2; // 高分获得更多优点
    allStrengths = getRandomItems(genericStrengths, strengthsCount);
  }
  
  return {
    overallScore: Math.round(overallScore * 10) / 10,
    dimensionScores: {
      fabeStructure,
      languageFluency,
      customerMatch,
      persuasion,
      confidence
    },
    suggestions: allSuggestions,
    strengths: allStrengths
  };
};
