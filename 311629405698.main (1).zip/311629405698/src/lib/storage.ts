import { PracticeRecord } from '../types';

const STORAGE_KEYS = {
  PRACTICE_RECORDS: 'fabe_practice_records',
  USER_PROFILE: 'fabe_user_profile',
  SETTINGS: 'fabe_settings'
};

// 保存练习记录
export const savePracticeRecord = (record: PracticeRecord): void => {
  try {
    const records = getPracticeRecords();
    records.push(record);
    localStorage.setItem(STORAGE_KEYS.PRACTICE_RECORDS, JSON.stringify(records));
  } catch (error) {
    console.error('保存练习记录失败:', error);
  }
};

// 获取所有练习记录
export const getPracticeRecords = (): PracticeRecord[] => {
  try {
    const records = localStorage.getItem(STORAGE_KEYS.PRACTICE_RECORDS);
    return records ? JSON.parse(records) : [];
  } catch (error) {
    console.error('获取练习记录失败:', error);
    return [];
  }
};

// 删除练习记录
export const deletePracticeRecord = (id: string): void => {
  try {
    const records = getPracticeRecords();
    const filteredRecords = records.filter(record => record.id !== id);
    localStorage.setItem(STORAGE_KEYS.PRACTICE_RECORDS, JSON.stringify(filteredRecords));
  } catch (error) {
    console.error('删除练习记录失败:', error);
  }
};

// 更新练习记录（用于添加AI评价）
export const updatePracticeRecord = (
  id: string,
  updates: Partial<PracticeRecord>
): void => {
  try {
    const records = getPracticeRecords();
    const index = records.findIndex(record => record.id === id);
    if (index !== -1) {
      records[index] = { ...records[index], ...updates };
      localStorage.setItem(STORAGE_KEYS.PRACTICE_RECORDS, JSON.stringify(records));
    }
  } catch (error) {
    console.error('更新练习记录失败:', error);
  }
};

// 清空所有练习记录
export const clearAllPracticeRecords = (): void => {
  try {
    localStorage.removeItem(STORAGE_KEYS.PRACTICE_RECORDS);
  } catch (error) {
    console.error('清空练习记录失败:', error);
  }
};