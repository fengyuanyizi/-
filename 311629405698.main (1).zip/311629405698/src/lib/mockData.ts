import { Product, Customer, ExcellentScript } from '../types';

// 模拟产品数据池
const productPool: Omit<Product, 'id'>[] = [
  {
    name: '智能手表 Pro',
    category: '电子产品',
    features: ['全天候心率监测', '血氧饱和度测量', '睡眠质量分析', '50米防水'],
    advantages: ['精准健康数据追踪', '超长续航可达14天', '多种运动模式支持', '轻薄设计舒适佩戴'],
    benefits: ['帮助用户更好地了解自己的健康状况', '减少充电频率，使用更便捷', '满足不同运动场景需求', '长时间佩戴不感不适'],
    evidence: ['获得多项国际健康认证', '用户满意度超过95%', '专业运动教练推荐使用', '连续三年销量领先'],
    price: 1299,
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Smart%20watch%2C%20modern%20design%2C%20fitness%20tracker&sign=26f1b74fc7294923ec0663bb54f6a8dc'
  },
  {
    name: '无线降噪耳机',
    category: '电子产品',
    features: ['主动降噪技术', '通透模式', '40小时续航', '快速充电'],
    advantages: ['隔绝90%环境噪音', '无需摘下耳机也能听清外界声音', '一周只需充电一次', '充电10分钟使用3小时'],
    benefits: ['提供沉浸式音乐体验', '在不同场景下灵活切换', '减少充电频率', '应急使用更有保障'],
    evidence: ['获得音频工程师协会认证', '专业音乐人推荐', '降噪效果测试报告显示优秀', '用户评价平均分4.8/5'],
    price: 899,
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Wireless%20noise-canceling%20headphones%2C%20premium%20sound&sign=ac275aa95975969fee2aae85fba53b41'
  },
  {
    name: '便携式咖啡机',
    category: '家用电器',
    features: ['一键操作', '800ml大容量水箱', '可调节咖啡浓度', '自动清洗功能'],
    advantages: ['操作简单，新手也能轻松使用', '一次可制作多杯咖啡', '满足不同口味需求', '使用后无需手动清洗'],
    benefits: ['节省时间，提高生活效率', '适合家庭或小型办公室使用', '个性化定制咖啡体验', '保持机器清洁，延长使用寿命'],
    evidence: ['德国红点设计奖获奖产品', '咖啡师推荐家用咖啡机', '用户反馈故障率低', '节能认证产品'],
    price: 599,
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Portable%20coffee%20machine%2C%20modern%20kitchen%20appliance&sign=9aa0540d42a065ff9ef2399e5a382dc7'
  },
  {
    name: '多功能料理机',
    category: '家用电器',
    features: ['10种烹饪模式', '智能预约功能', '不粘涂层', '安全童锁'],
    advantages: ['一机多用，节省厨房空间', '提前准备，节省时间', '清洁方便，不粘锅底', '防止儿童误操作'],
    benefits: ['满足家庭多样化烹饪需求', '让早餐准备更轻松', '减少清洁负担', '使用更安全放心'],
    evidence: ['年度最佳厨房电器奖', '消费者协会推荐产品', '耐用性测试超过1000次循环', '低能耗设计'],
    price: 799,
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Multifunctional%20cooking%20machine%2C%20kitchen%20appliance&sign=724e6843571e17497205086ddebc2e19'
  }
];

// 模拟客户数据池
const customerPool: Omit<Customer, 'id'>[] = [
  {
    name: '张小姐',
    age: 28,
    occupation: '办公室白领',
    needs: ['提高工作效率', '改善健康状况', '方便携带'],
    preferences: ['简约设计', '高性价比', '知名品牌'],
    concerns: ['价格偏高', '使用复杂', '质量不可靠'],
    personality: '理智型'
  },
  {
    name: '李先生',
    age: 35,
    occupation: '健身教练',
    needs: ['精准数据追踪', '耐用性强', '专业功能'],
    preferences: ['运动风格', '专业品牌', '高性能'],
    concerns: ['功能不实用', '电池续航短', '防水性能差'],
    personality: '冲动型'
  },
  {
    name: '王阿姨',
    age: 55,
    occupation: '退休教师',
    needs: ['操作简单', '易于清洁', '安全可靠'],
    preferences: ['口碑好', '实用耐用', '性价比高'],
    concerns: ['使用复杂', '不安全', '维修麻烦'],
    personality: '谨慎型'
  },
  {
    name: '赵先生',
    age: 42,
    occupation: '企业管理者',
    needs: ['提升生活品质', '彰显品味', '高效便捷'],
    preferences: ['高端品牌', '独特设计', '定制服务'],
    concerns: ['性价比低', '售后服务差', '过时快'],
    personality: '情感型'
  }
];

// 优秀话术示例数据池
const excellentScriptsPool: Omit<ExcellentScript, 'id'>[] = [
  {
    productId: '智能手表 Pro',
    customerTypeId: '理智型',
    script: '张小姐，我看您平时工作挺忙的，既要赶方案又要参加各种会议，肯定特别在意效率和身体状况吧？您看这款智能手表 Pro，我觉得特别适合您这种职场精英。它能24小时监测心率和血氧，您在办公室久坐或者赶项目熬夜的时候，随时都能查看自己的健康数据，就像有个私人健康助理在身边提醒您。而且它的睡眠分析功能特别准，您晚上睡不好的话，第二天早上打开手表就能看到具体的睡眠阶段分析，帮您调整作息规律。对了，最实用的是它充一次电可以用14天，您根本不用天天想着充电的事儿，特别省心。这款手表已经通过了国际健康认证，我们公司好多同事都在用，都说数据准确又耐用。您觉得这些功能对您平衡工作和健康有帮助吗？',
    fabeBreakdown: {
      feature: '全天候心率监测、血氧饱和度测量、睡眠质量分析、14天超长续航',
      advantage: '随时掌握健康数据、精准分析睡眠状况、减少充电频率',
      benefit: '工作再忙也能关注健康、改善睡眠质量、提高工作效率',
      evidence: '获得多项国际健康认证、办公室同事实际使用体验、用户满意度超过95%'
    },
    tips: ['针对理智型客户，用具体场景和数据说话', '结合办公室工作场景，让客户有代入感', '用提问引导客户思考产品对自己的实际价值', '提到同事使用案例，增加可信度']
  },
  {
    productId: '无线降噪耳机',
    customerTypeId: '冲动型',
    script: '嘿，李教练！我看您带学员训练的时候总是很有激情，应该也是个爱音乐的人吧？跟您说，这款无线降噪耳机您绝对得试试！您平时在健身房带课或者自己训练时，周围肯定特别吵吧？这耳机的主动降噪能隔掉90%的噪音，您听音乐或者听教学音频的时候，就像在安静的录音棚里一样，特别沉浸！而且它还有通透模式，您带学员的时候不用摘耳机就能听清他们说话，特别方便。关键是续航太牛了，充一次电能用40个小时，您一周训练下来都不用充电！对了，它还有快充功能，有时候忘了充电，10分钟就能续3小时，完全不耽误您带课。好多健身教练和专业运动员都在用这款，都说音质好、耐用又实用。来，您带上感受一下，听听这音质和降噪效果！',
    fabeBreakdown: {
      feature: '主动降噪技术、通透模式、40小时续航、快速充电',
      advantage: '隔绝健身房噪音、无需摘耳机沟通、一周只需充电一次',
      benefit: '提供沉浸式音乐体验、带课更方便、不耽误训练计划',
      evidence: '专业运动员和健身教练使用推荐、用户评价平均分4.8/5、降噪效果专业测试认证'
    },
    tips: ['用充满活力的语气和教练交流，符合冲动型客户的性格', '结合健身房训练场景，让客户立刻联想到使用场景', '强调产品的专业属性和其他专业人士的使用情况', '鼓励客户亲身体验，促进快速决策']
  },
  {
    productId: '便携式咖啡机',
    customerTypeId: '谨慎型',
    script: '王阿姨，您好！看您平时喜欢在家看看书、养养花草，肯定也喜欢喝上一杯自己煮的热咖啡吧？我给您推荐这款便携式咖啡机，特别适合像您这样追求生活品质又怕麻烦的人。您看，它操作特别简单，就一个按钮，一按就能自动完成研磨、冲泡，您第一次用就能上手，完全不用担心不会操作。而且它的水箱有800毫升，一次能煮4-5杯，您要是有朋友来家里做客，也不用一杯一杯地煮，多方便啊。最贴心的是它有自动清洗功能，用完了按一下按钮，机器自己就清洗干净了，您不用动手洗，也不用担心藏污纳垢。这款咖啡机是德国红点设计奖的产品，质量特别可靠，我有个邻居张阿姨用了两年多了，从来没出过问题。价格也很实在，只要599块钱，比外面买咖啡可划算多了。您看，这机器小巧不占地方，放在您家客厅或者厨房都合适，您要不要考虑一下？',
    fabeBreakdown: {
      feature: '一键操作、800ml大容量水箱、可调节咖啡浓度、自动清洗功能',
      advantage: '操作简单易上手、一次可煮多杯、无需手动清洗',
      benefit: '享受自制咖啡的乐趣、方便招待朋友、省时省力',
      evidence: '德国红点设计奖获奖产品、邻居实际使用两年无故障、节能认证产品'
    },
    tips: ['用亲切的称呼和语气与退休教师交流', '强调操作简单和安全可靠，打消谨慎型客户的顾虑', '用邻居使用案例增加可信度', '提到价格实惠，符合节俭的消费心理']
  },
  {
    productId: '多功能料理机',
    customerTypeId: '情感型',
    script: '赵总，我看您平时工作这么忙，肯定特别希望回家能吃上一口热乎饭，又不想把太多时间花在厨房吧？这款多功能料理机简直是为您这样注重生活品质的成功人士设计的。您看，它有10种烹饪模式，从煮粥、炖汤到炒菜、烘焙，几乎涵盖了所有家常菜品，一台机器就能搞定您家的一日三餐，既节省了厨房空间，又省去了买各种厨具的麻烦。最贴心的是它的智能预约功能，您早上出门前把食材放进去，设置好时间，晚上下班回家就能闻到香喷喷的饭菜香，特别温暖。对了，它的不粘涂层特别好清理，做完饭用厨房纸一擦就干净了，完全不会让您为了洗碗而烦恼。而且它还有安全童锁，您家有孩子的话，也不用担心孩子误触发生危险。这款料理机是今年的"最佳厨房电器"，设计特别精美，放在您家现代化的厨房里，绝对是一道亮丽的风景线。您觉得，有了它，是不是能让您的家庭生活更温馨、更有品质呢？',
    fabeBreakdown: {
      feature: '10种烹饪模式、智能预约功能、不粘涂层、安全童锁',
      advantage: '一机多用节省空间、提前预约节省时间、清洁方便、安全有保障',
      benefit: '享受温馨家庭餐、平衡工作与生活、提升生活品质',
      evidence: '年度最佳厨房电器奖、消费者协会推荐、耐用性测试超过1000次循环'
    },
    tips: ['用温暖感性的语言与情感型客户交流', '强调产品带来的家庭温馨感和生活品质提升', '突出产品设计精美，符合高端审美', '关注家庭安全，体现对客户家人的关心']
  }
];

// 生成随机ID
const generateId = (): string => {
  return Math.random().toString(36).substr(2, 9);
};

// 随机获取产品
export const getRandomProduct = (): Product => {
  const product = { ...productPool[Math.floor(Math.random() * productPool.length)] };
  return { ...product, id: generateId() };
};

// 随机获取客户
export const getRandomCustomer = (): Customer => {
  const customer = { ...customerPool[Math.floor(Math.random() * customerPool.length)] };
  return { ...customer, id: generateId() };
};

// 根据产品和客户类型获取优秀话术
export const getExcellentScript = (productName: string, customerPersonality: string): ExcellentScript => {
  // 尝试找到完全匹配的话术
  const matchedScript = excellentScriptsPool.find(script => 
    script.productId === productName && script.customerTypeId === customerPersonality
  );
  
  if (matchedScript) {
    return { ...matchedScript, id: generateId() };
  }
  
  // 如果没有完全匹配的，则返回任意一个相关的话术
  const relatedScripts = excellentScriptsPool.filter(script => 
    script.productId === productName || script.customerTypeId === customerPersonality
  );
  
  if (relatedScripts.length > 0) {
    const randomScript = relatedScripts[Math.floor(Math.random() * relatedScripts.length)];
    return { ...randomScript, id: generateId() };
  }
  
  // 如果没有相关的，则返回第一个话术
  const firstScript = excellentScriptsPool[0];
  return { ...firstScript, id: generateId() };
};