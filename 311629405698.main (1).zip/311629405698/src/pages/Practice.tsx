import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { ProductCard } from '../components/ProductCard';
import { CustomerCard } from '../components/CustomerCard';
import { Recorder } from '../components/Recorder';
import { NavBar } from '../components/NavBar';
import { getRandomProduct, getRandomCustomer, getExcellentScript } from '../lib/mockData';
import { savePracticeRecord } from '../lib/storage';
import { Product, Customer, PracticeRecord, AIEvaluation, ExcellentScript } from '../types';
import { useTheme } from '../hooks/useTheme';
import { downloadRecording, generateAIEvaluation } from '../lib/utils';

// 练习流程的不同阶段
type PracticeStep = 'preparation' | 'recording' | 'evaluation' | 'completed';

export default function Practice() {
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [step, setStep] = useState<PracticeStep>('preparation');
  const [product, setProduct] = useState<Product | null>(null);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [recordingBlob, setRecordingBlob] = useState<Blob | null>(null);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [aiEvaluation, setAiEvaluation] = useState<AIEvaluation | null>(null);
  const [excellentScript, setExcellentScript] = useState<ExcellentScript | null>(null);
  
  // 生成新的练习数据
  const generateNewPractice = () => {
    setProduct(getRandomProduct());
    setCustomer(getRandomCustomer());
    setStep('preparation');
    setRecordingBlob(null);
    setRecordingDuration(0);
    setAiEvaluation(null);
    setExcellentScript(null);
  };
  
  // 初始化练习数据
  useEffect(() => {
    generateNewPractice();
  }, []);
  
  // 处理录制完成
  const handleRecordingComplete = (blob: Blob, duration: number) => {
    setRecordingBlob(blob);
    setRecordingDuration(duration);
    
    // 模拟AI评价生成
    toast.info('AI正在分析您的练习...');
    setTimeout(() => {
      if (product && customer) {
        // 生成AI评价，传入产品和客户信息以获得更个性化的评价
        const evaluation = generateAIEvaluation(product.name, {
          personality: customer.personality,
          needs: customer.needs,
          concerns: customer.concerns
        });
        setAiEvaluation(evaluation);
        
        // 获取优秀话术示例
        const script = getExcellentScript(product.name, customer.personality);
        setExcellentScript(script);
        
        // 保存练习记录
        savePracticeRecord({
          id: Math.random().toString(36).substr(2, 9),
          date: new Date().toISOString(),
          productId: product.id,
          customerId: customer.id,
          recordingUrl: URL.createObjectURL(blob),
          duration: duration,
          aiEvaluation: evaluation
        });
        
        setStep('evaluation');
        toast.success('AI评价已生成，请查看详细分析和优秀话术示例');
      }
    }, 2000); // 稍微延长等待时间，让评价生成过程感觉更真实
  };
  
  // 进行新的练习
  const handleNewPractice = () => {
    generateNewPractice();
  };
  
  // 查看练习历史
  const handleViewHistory = () => {
    navigate('/history');
  };
  
  // 下载录音
  const handleDownloadRecording = () => {
    if (recordingBlob && product) {
      downloadRecording(recordingBlob, `${product.name}_推销练习`);
      toast.success('录音已下载到设备');
    }
  };
  
  // 准备阶段内容
  const renderPreparationStep = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {product && <ProductCard product={product} />}
      {customer && <CustomerCard customer={customer} />}
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
        className="bg-blue-50 dark:bg-blue-900/20 rounded-2xl p-6 border border-blue-100 dark:border-blue-800"
      >
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-3 flex items-center">
          <i className="fas fa-lightbulb text-yellow-500 mr-2"></i>
          练习提示
        </h2>
        <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 space-y-2 pl-4">
          <li>仔细阅读产品的FABE特性</li>
          <li>分析客户的需求、偏好和顾虑</li>
          <li>结合产品特性和客户情况，准备您的推销话术</li>
          <li>点击"开始录制"按钮，开始您的练习</li>
        </ul>
      </motion.div>
      
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => setStep('recording')}
        className="w-full py-4 bg-green-500 hover:bg-green-600 text-white font-bold text-lg rounded-full transition-colors shadow-lg flex items-center justify-center gap-2"
      >
        <i className="fas fa-microphone"></i>
        开始录制
      </motion.button>
    </motion.div>
  );
  
  // 录制阶段内容
  const renderRecordingStep = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {product && <ProductCard product={product} />}
        {customer && <CustomerCard customer={customer} />}
      </div>
      
      <Recorder onRecordingComplete={handleRecordingComplete} />
    </motion.div>
  );
  
  // 评价阶段内容
  const renderEvaluationStep = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {product && <ProductCard product={product} />}
        {customer && <CustomerCard customer={customer} />}
      </div>
      
      {/* 录音回放和下载 */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700"
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">录音回放</h2>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleDownloadRecording}
            className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors flex items-center gap-2"
          >
            <i className="fas fa-download"></i>
            <span className="text-sm">下载录音</span>
          </motion.button>
        </div>
        
        {recordingBlob && (
          <div className="bg-gray-100 dark:bg-gray-700 rounded-xl p-4">
            <audio controls src={URL.createObjectURL(recordingBlob)} className="w-full">
              您的浏览器不支持音频播放。
            </audio>
            <p className="text-center text-gray-500 dark:text-gray-400 text-sm mt-2">
              时长: {Math.floor(recordingDuration / 60)}:{(recordingDuration % 60).toString().padStart(2, '0')}
            </p>
          </div>
        )}
      </motion.div>
      
      {/* AI评价 */}
      {aiEvaluation && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700"
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
              <i className="fas fa-robot text-blue-500"></i>
            </div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">AI评价分析</h2>
          </div>
          
          {/* 总评分 */}
          <div className="mb-6 text-center">
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-blue-100 dark:bg-blue-900/30 mb-2">
              <span className="text-4xl font-bold text-blue-500">{aiEvaluation.overallScore}</span>
            </div>
            <p className="text-gray-600 dark:text-gray-300">总体评分 (满分5分)</p>
          </div>
          
          {/* 维度评分 */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3">维度评分</h3>
            <div className="space-y-4">
              {Object.entries(aiEvaluation.dimensionScores).map(([key, score]) => {
                const dimensionLabels: Record<string, string> = {
                  fabeStructure: 'FABE结构完整性',
                  languageFluency: '语言流畅度',
                  customerMatch: '客户需求匹配度',
                  persuasion: '说服力',
                  confidence: '自信度'
                };
                
                return (
                  <div key={key}>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {dimensionLabels[key]}
                      </span>
                      <span className="text-sm font-medium text-blue-500">{score}/5</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-blue-500 h-2 rounded-full transition-all duration-1000 ease-out" 
                        style={{ width: `${(score / 5) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* 优点和建议 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 优点 */}
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-xl">
              <h3 className="font-semibold text-green-600 dark:text-green-400 mb-2 flex items-center">
                <i className="fas fa-thumbs-up mr-2"></i>
                优点
              </h3>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-1 text-sm">
                {aiEvaluation.strengths.map((strength, index) => (
                  <li key={index}>{strength}</li>
                ))}
              </ul>
            </div>
            
            {/* 建议 */}
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl">
              <h3 className="font-semibold text-blue-600 dark:text-blue-400 mb-2 flex items-center">
                <i className="fas fa-lightbulb mr-2"></i>
                建议
              </h3>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-1 text-sm">
                {aiEvaluation.suggestions.map((suggestion, index) => (
                  <li key={index}>{suggestion}</li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>
      )}
       
      {/* 优秀话术示例 */}
      {excellentScript && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700"
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
              <i className="fas fa-trophy text-green-500"></i>
            </div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">优秀话术示例</h2>
          </div>
          
          {/* 完整话术 */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">完整话术</h3>
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-xl border border-green-100 dark:border-green-800">
              <p className="text-gray-700 dark:text-gray-300 whitespace-pre-line">{excellentScript.script}</p>
            </div>
          </div>
          
          {/* FABE分解 */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3">FABE结构分解</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-xl border border-blue-100 dark:border-blue-800">
                <h4 className="font-medium text-blue-600 dark:text-blue-400 mb-1 flex items-center">
                  <span className="inline-block w-5 h-5 rounded-full bg-blue-500 text-white text-xs font-bold flex items-center justify-center mr-1">F</span>
                  特征
                </h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">{excellentScript.fabeBreakdown.feature}</p>
              </div>
              
              <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-xl border border-green-100 dark:border-green-800">
                <h4 className="font-medium text-green-600 dark:text-green-400 mb-1 flex items-center">
                  <span className="inline-block w-5 h-5 rounded-full bg-green-500 text-white text-xs font-bold flex items-center justify-center mr-1">A</span>
                  优势
                </h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">{excellentScript.fabeBreakdown.advantage}</p>
              </div>
              
              <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-xl border border-yellow-100 dark:border-yellow-800">
                <h4 className="font-medium text-yellow-600 dark:text-yellow-400 mb-1 flex items-center">
                  <span className="inline-block w-5 h-5 rounded-full bg-yellow-500 text-white text-xs font-bold flex items-center justify-center mr-1">B</span>
                  利益
                </h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">{excellentScript.fabeBreakdown.benefit}</p>
              </div>
              
              <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-xl border border-purple-100 dark:border-purple-800">
                <h4 className="font-medium text-purple-600 dark:text-purple-400 mb-1 flex items-center">
                  <span className="inline-block w-5 h-5 rounded-full bg-purple-500 text-white text-xs font-bold flex items-center justify-center mr-1">E</span>
                  证据
                </h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">{excellentScript.fabeBreakdown.evidence}</p>
              </div>
            </div>
          </div>
          
          {/* 话术技巧提示 */}
          <div>
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">话术技巧提示</h3>
            <ul className="space-y-2">
              {excellentScript.tips.map((tip, index) => (
                <li key={index} className="flex items-start gap-2">
                  <i className="fas fa-lightbulb text-yellow-500 mt-1 flex-shrink-0"></i>
                  <p className="text-gray-700 dark:text-gray-300">{tip}</p>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>
      )}
      
      {/* 完成按钮 */}
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        onClick={() => setStep('completed')}
        className="w-full py-4 bg-green-500 hover:bg-green-600 text-white font-bold text-lg rounded-full transition-colors shadow-lg mt-6"
      >
        完成练习
      </motion.button>
    </motion.div>
  );
  
  // 完成阶段内容
  const renderCompletedStep = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="text-center py-12"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, type: "spring" }}
        className="w-24 h-24 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-6"
      >
        <i className="fas fa-check text-green-500 dark:text-green-400 text-4xl"></i>
      </motion.div>
      
      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">练习完成！</h2>
      <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-md mx-auto">
        您已经成功完成了一次FABE推销练习。继续努力，您的销售技巧将会不断提升！
      </p>
      
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleNewPractice}
          className="px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-full transition-colors shadow-md"
        >
          继续练习
        </motion.button>
        
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleViewHistory}
          className="px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-800 dark:bg-gray-700 dark:hover:bg-gray-600 dark:text-gray-200 font-medium rounded-full transition-colors shadow-md"
        >
          查看历史
        </motion.button>
      </div>
    </motion.div>
  );
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col pb-32 md:pb-0 md:pl-64">
      {/* 顶部栏 */}
      <header className="sticky top-0 z-40 bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">
            {step === 'preparation' && '准备练习'}
            {step === 'recording' && '正在录制'}
            {step === 'evaluation' && '练习评价'}
            {step === 'completed' && '练习完成'}
          </h1>
          <div className="flex items-center gap-2">
            <button 
              onClick={toggleTheme} 
              className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
              aria-label="切换主题"
            >
              {theme === 'light' ? (
                <i className="fas fa-moon"></i>
              ) : (
                <i className="fas fa-sun"></i>
              )}
            </button>
          </div>
        </div>
      </header>
      
      {/* 主要内容 */}
      <main className="flex-1 container mx-auto px-4 py-8">
        {step === 'preparation' && renderPreparationStep()}
        {step === 'recording' && renderRecordingStep()}
        {step === 'evaluation' && renderEvaluationStep()}
        {step === 'completed' && renderCompletedStep()}
      </main>
      
      {/* 导航栏 */}
      <NavBar />
    </div>
  );
}