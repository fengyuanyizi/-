import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { NavBar } from '../components/NavBar';
import { useTheme } from '../hooks/useTheme';
import { getPracticeRecords, clearAllPracticeRecords } from '../lib/storage';
import { toast } from 'sonner';

// 统计项组件
interface StatItemProps {
  label: string;
  value: string | number;
  icon: string;
  color: 'blue' | 'green' | 'yellow' | 'purple' | 'red';
}

const StatItem: React.FC<StatItemProps> = ({ label, value, icon, color }) => {
  const colorMap = {
    blue: 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400',
    green: 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400',
    yellow: 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-400',
    purple: 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400',
    red: 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400'
  };
  
  return (
    <div className="text-center">
      <div className={`inline-flex w-12 h-12 ${colorMap[color]} rounded-full items-center justify-center mb-2`}>
        <i className={`fas ${icon}`}></i>
      </div>
      <p className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{value}</p>
      <p className="text-sm text-gray-500 dark:text-gray-400">{label}</p>
    </div>
  );
};

// 模拟用户数据
const getUserData = () => {
  return {
    name: '张同学',
    avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Student%20avatar%2C%20asian%20young%20person&sign=65a2692195aad098d2c9489d2b13f0a4',
    role: '学生',
    progress: {
      totalPractices: 15,
      averageScore: 4.2,
      completionRate: 85,
      improvementTrend: '上升'
    },
    achievements: [
      { id: 1, name: '初次尝试', description: '完成第一次FABE推销练习' },
      { id: 2, name: '坚持不懈', description: '连续练习5天' },
      { id: 3, name: '销售之星', description: '获得一次满分评价' }
    ]
  };
};

// 练习统计数据
const getPracticeStats = () => {
  const records = getPracticeRecords();
  const scoredRecords = records.filter(r => r.score !== undefined);
  
  return {
    totalPractices: records.length,
    averageScore: scoredRecords.length > 0 
      ? (scoredRecords.reduce((sum, r) => sum + (r.score || 0), 0) / scoredRecords.length).toFixed(1)
      : '0.0',
    totalDuration: records.reduce((sum, r) => sum + r.duration, 0),
    highestScore: scoredRecords.length > 0 
      ? Math.max(...scoredRecords.map(r => r.score || 0))
      : 0
  };
};

export default function Profile() {
  const { theme, toggleTheme } = useTheme();
  const [userData, setUserData] = useState(getUserData());
  const [practiceStats, setPracticeStats] = useState(getPracticeStats());
  const [isDarkMode, setIsDarkMode] = useState(theme === 'dark');
  
  // 格式化时长
  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0) {
      return `${hours}小时${minutes}分钟`;
    }
    return `${minutes}分钟`;
  };
  
  // 切换深色模式
  const handleThemeToggle = () => {
    toggleTheme();
    setIsDarkMode(prev => !prev);
  };
  
  // 清除所有练习记录
  const handleClearRecords = () => {
    if (window.confirm('确定要清除所有练习记录吗？此操作不可恢复。')) {
      clearAllPracticeRecords();
      setPracticeStats(getPracticeStats());
      toast.success('所有练习记录已清除');
    }
  };
  
  // 当主题改变时更新状态
  useEffect(() => {
    setIsDarkMode(theme === 'dark');
  }, [theme]);
  
  // 刷新统计数据
  const refreshStats = () => {
    setPracticeStats(getPracticeStats());
    toast.success('统计数据已更新');
  };
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col pb-20 md:pb-0 md:pl-64">
      {/* 顶部栏 */}
      <header className="sticky top-0 z-40 bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">个人中心</h1>
          <div className="flex items-center gap-2">
            <button 
              onClick={toggleTheme} 
              className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
              aria-label="切换主题"
            >
              {theme === 'light' ? (
                <i className="fas fa-moon"></i>
              ) : (
                <i className="fas fa-sun"></i>
              )}
            </button>
          </div>
        </div>
      </header>
      
      {/* 主要内容 */}
      <main className="flex-1 container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="space-y-8"
        >
          {/* 用户信息卡片 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
          >
            <div className="flex flex-col md:flex-row md:items-center gap-6">
              {/* 头像 */}
              <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-blue-100 dark:border-blue-900 flex-shrink-0">
                <img 
                  src={userData.avatar} 
                  alt={userData.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* 用户信息 */}
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{userData.name}</h2>
                <p className="text-gray-500 dark:text-gray-400 mb-4">{userData.role}</p>
                
                {/* 进度条 */}
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-300">学习进度</span>
                    <span className="text-sm font-medium text-blue-500">{userData.progress.completionRate}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div 
                      className="bg-blue-500 h-2.5 rounded-full" 
                      style={{ width: `${userData.progress.completionRate}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* 练习统计卡片 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">练习统计</h2>
              <button 
                onClick={refreshStats}
                className="text-blue-500 hover:text-blue-600 transition-colors"
                aria-label="刷新统计数据"
              >
                <i className="fas fa-sync-alt"></i>
              </button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatItem 
                label="总练习次数" 
                value={practiceStats.totalPractices} 
                icon="fa-history" 
                color="blue" 
              />
              <StatItem 
                label="平均评分" 
                value={practiceStats.averageScore} 
                icon="fa-star" 
                color="yellow" 
              />
              <StatItem 
                label="总练习时长" 
                value={formatDuration(practiceStats.totalDuration)} 
                icon="fa-clock" 
                color="green" 
              />
              <StatItem 
                label="最高评分" 
                value={practiceStats.highestScore} 
                icon="fa-trophy" 
                color="purple" 
              />
            </div>
          </motion.div>
          
          {/* 成就卡片 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
          >
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">获得成就</h2>
            
            <div className="space-y-4">
              {userData.achievements.length > 0 ? (
                userData.achievements.map((achievement) => (
                  <motion.div
                    key={achievement.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3 }}
                    className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl"
                  >
                    <div className="w-10 h-10 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <i className="fas fa-award"></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-white">{achievement.name}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{achievement.description}</p>
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <i className="fas fa-medal text-3xl mb-2"></i>
                  <p>暂无成就，继续努力！</p>
                </div>
              )}
            </div>
          </motion.div>
          
          {/* 设置 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
          >
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">设置</h2>
            
            <div className="space-y-4">
              {/* 深色模式开关 */}
              <div className="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 rounded-xl transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-500 rounded-full flex items-center justify-center">
                    <i className="fas fa-moon"></i>
                  </div>
                  <span className="text-gray-800 dark:text-gray-200">深色模式</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={isDarkMode} 
                    onChange={handleThemeToggle}
                    className="sr-only peer" 
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-500 dark:peer-focus:ring-blue-400 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-500"></div>
                </label>
              </div>
              
              {/* 清除数据 */}
              <div 
                className="flex items-center justify-between p-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-xl transition-colors cursor-pointer"
                onClick={handleClearRecords}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center">
                    <i className="fas fa-trash-alt"></i>
                  </div>
                  <span>清除所有练习记录</span>
                </div>
                <i className="fas fa-chevron-right text-sm"></i>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </main>
      
      {/* 导航栏 */}
      <NavBar />
    </div>
  );
}