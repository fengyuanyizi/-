import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { NavBar } from '../components/NavBar';
import { useTheme } from '../hooks/useTheme';

// 功能卡片组件
interface FeatureCardProps {
  icon: string;
  title: string;
  description: string;
  color: 'blue' | 'green' | 'purple' | 'red' | 'yellow';
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description, color }) => {
  const colorMap = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    purple: 'bg-purple-500',
    red: 'bg-red-500',
    yellow: 'bg-yellow-500'
  };
  
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
    >
      <div className={`w-12 h-12 ${colorMap[color]} rounded-xl flex items-center justify-center mb-4 text-white`}>
        <i className={`fas ${icon} text-xl`}></i>
      </div>
      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{title}</h3>
      <p className="text-gray-600 dark:text-gray-300">{description}</p>
    </motion.div>
  );
};

export default function Home() {
  const { theme, toggleTheme } = useTheme();
  
  // 动画变体
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col pb-20 md:pb-0 md:pl-64">
      {/* 顶部栏 */}
      <header className="sticky top-0 z-40 bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-gray-800 dark:text-white md:hidden">FABE推销话术训练</h1>
          <button 
            onClick={toggleTheme} 
            className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
            aria-label="切换主题"
          >
            {theme === 'light' ? (
              <i className="fas fa-moon"></i>
            ) : (
              <i className="fas fa-sun"></i>
            )}
          </button>
        </div>
      </header>
      
      {/* 主要内容 */}
      <main className="flex-1 container mx-auto px-4 py-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-8"
        >
          {/* 欢迎部分 */}
          <motion.section variants={itemVariants} className="text-center mb-8">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="w-24 h-24 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4"
            >
              <i className="fas fa-bullhorn text-blue-500 dark:text-blue-400 text-4xl"></i>
            </motion.div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-3">
              FABE推销话术训练
            </h1>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              提升您的销售技巧，掌握专业的FABE推销模式，成为顶尖销售人才。
            </p>
          </motion.section>
          
          {/* 开始练习按钮 */}
          <motion.section variants={itemVariants} className="flex justify-center">
            <Link to="/practice">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-blue-500 hover:bg-blue-600 text-white font-bold text-xl rounded-full shadow-lg transition-all flex items-center gap-2"
              >
                <i className="fas fa-play-circle"></i>
                开始练习
              </motion.button>
            </Link>
          </motion.section>
          
          {/* 功能介绍卡片 */}
          <motion.section variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard 
              icon="fa-random" 
              title="随机生成练习" 
              description="系统随机生成产品信息和客户情况，让您面对各种不同的销售场景。"
              color="blue"
            />
            <FeatureCard 
              icon="fa-microphone" 
              title="录音练习" 
              description="录制您的推销过程，回放分析自己的表现，不断改进提高。"
              color="purple"
            />
            <FeatureCard 
              icon="fa-star" 
              title="评价与反馈" 
              description="记录每次练习的评分和改进点，追踪您的成长轨迹。"
              color="green"
            />
          </motion.section>
          
          {/* FABE模式介绍 */}
          <motion.section variants={itemVariants}>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">什么是FABE模式？</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                FABE模式是一种有效的推销技巧，通过四个关键步骤向客户展示产品价值：
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl border border-blue-100 dark:border-blue-800">
                  <h3 className="font-bold text-blue-600 dark:text-blue-400 mb-2 flex items-center">
                    <span className="inline-block w-6 h-6 rounded-full bg-blue-500 text-white text-xs font-bold flex items-center justify-center mr-2">F</span>
                    特征（Feature）
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300">产品的特性、功能或事实，如材质、尺寸、颜色等。</p>
                </div>
                
                <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-xl border border-green-100 dark:border-green-800">
                  <h3 className="font-bold text-green-600 dark:text-green-400 mb-2 flex items-center">
                    <span className="inline-block w-6 h-6 rounded-full bg-green-500 text-white text-xs font-bold flex items-center justify-center mr-2">A</span>
                    优势（Advantage）
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300">产品如何使用这些特征，比竞争对手好在哪里。</p>
                </div>
                
                <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-xl border border-yellow-100 dark:border-yellow-800">
                  <h3 className="font-bold text-yellow-600 dark:text-yellow-400 mb-2 flex items-center">
                    <span className="inline-block w-6 h-6 rounded-full bg-yellow-500 text-white text-xs font-bold flex items-center justify-center mr-2">B</span>
                    利益（Benefit）
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300">产品能为客户带来什么好处，满足什么需求。</p>
                </div>
                
                <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-xl border border-purple-100 dark:border-purple-800">
                  <h3 className="font-bold text-purple-600 dark:text-purple-400 mb-2 flex items-center">
                    <span className="inline-block w-6 h-6 rounded-full bg-purple-500 text-white text-xs font-bold flex items-center justify-center mr-2">E</span>
                    证据（Evidence）
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300">用数据、案例、证明等方式验证您的说法。</p>
                </div>
              </div>
            </div>
          </motion.section>
        </motion.div>
      </main>
      
      {/* 导航栏 */}
      <NavBar />
    </div>
  );
}