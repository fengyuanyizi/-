import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { NavBar } from '../components/NavBar';
import { useTheme } from '../hooks/useTheme';
import { getPracticeRecords, deletePracticeRecord, updatePracticeRecord } from '../lib/storage';
import { PracticeRecord, Product, Customer } from '../types';
import { Rating } from '../components/Rating';
import { toast } from 'sonner';

// 统计卡片组件
interface StatCardProps {
  title: string;
  value: string | number;
  icon: string;
  color: 'blue' | 'green' | 'yellow' | 'purple' | 'red';
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, color }) => {
  const colorMap = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    yellow: 'bg-yellow-500',
    purple: 'bg-purple-500',
    red: 'bg-red-500'
  };
  
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-md border border-gray-100 dark:border-gray-700"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-gray-500 dark:text-gray-400 font-medium">{title}</h3>
        <div className={`w-10 h-10 ${colorMap[color]} rounded-full flex items-center justify-center text-white`}>
          <i className={`fas ${icon}`}></i>
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 dark:text-white">{value}</p>
    </motion.div>
  );
};

// 模拟获取产品信息的函数（实际应用中应该从API获取）
const getProductById = (id: string): Product | null => {
  // 这里应该是从真实数据源获取产品信息的逻辑
  // 为了演示，我们返回一个模拟的产品对象
  return {
    id,
    name: '智能产品',
    category: '电子产品',
    features: ['高品质', '多功能'],
    advantages: ['性能优秀', '使用方便'],
    benefits: ['提升效率', '改善生活'],
    evidence: ['用户好评', '销量领先'],
    price: 999,
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Smart%20product%20mockup&sign=6b0739f51c834ed7e6728fb00b4b9a7f'
  };
};

// 模拟获取客户信息的函数（实际应用中应该从API获取）
const getCustomerById = (id: string): Customer | null => {
  // 这里应该是从真实数据源获取客户信息的逻辑
  // 为了演示，我们返回一个模拟的客户对象
  return {
    id,
    name: '客户',
    age: 30,
    occupation: '专业人士',
    needs: ['高品质', '高效率'],
    preferences: ['品牌', '服务'],
    concerns: ['价格', '质量'],
    personality: '理智型'
  };
};

export default function History() {
  const { theme, toggleTheme } = useTheme();
  const [records, setRecords] = useState<PracticeRecord[]>([]);
  const [selectedRecord, setSelectedRecord] = useState<PracticeRecord | null>(null);
  const [isRatingModalOpen, setIsRatingModalOpen] = useState(false);
  
  // 获取练习记录
  const fetchRecords = () => {
    const practiceRecords = getPracticeRecords();
    // 按时间倒序排列
    setRecords(practiceRecords.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
  };
  
  // 初始化时获取记录
  useEffect(() => {
    fetchRecords();
  }, []);
  
  // 处理删除记录
  const handleDeleteRecord = (id: string) => {if (window.confirm('确定要删除这条练习记录吗？')) {
      deletePracticeRecord(id);
      fetchRecords();
      toast.success('练习记录已删除');
    }
  };
  
  // 处理编辑评价
  const handleEditRating = (record: PracticeRecord) => {
    setSelectedRecord(record);
    setIsRatingModalOpen(true);
  };
  
   // 处理评价更新（保留原函数结构，避免报错）
  const handleRatingUpdate = (score: number, comments: string, improvementPoints: string[]) => {
    // 由于现在只使用AI评价，此函数保留但不执行任何操作
    toast.info('系统已使用AI评价，无需手动评价');
    setIsRatingModalOpen(false);
  };
  
  // 格式化日期时间
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  // 格式化时长
  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col pb-20 md:pb-0 md:pl-64">
      {/* 顶部栏 */}
      <header className="sticky top-0 z-40 bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">练习记录</h1>
          <div className="flex items-center gap-2">
            <button 
              onClick={toggleTheme} 
              className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
              aria-label="切换主题"
            >
              {theme === 'light' ? (
                <i className="fas fa-moon"></i>
              ) : (
                <i className="fas fa-sun"></i>
              )}
            </button>
          </div>
        </div>
      </header>
      
      {/* 主要内容 */}
      <main className="flex-1 container mx-auto px-4 py-8">
        {/* 统计信息 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8"
        >
          <StatCard 
            title="总练习次数" 
            value={records.length} 
            icon="fa-history" 
            color="blue" 
          />
          <StatCard 
            title="平均评分" 
            value={records.length > 0 
              ? (records.filter(r => r.score !== undefined).reduce((sum, r) => sum + (r.score || 0), 0) / 
                 records.filter(r => r.score !== undefined).length).toFixed(1) 
              : '0.0'} 
            icon="fa-star" 
            color="yellow" 
          />
          <StatCard 
            title="总练习时长" 
            value={formatDuration(records.reduce((sum, r) => sum + r.duration, 0))} 
            icon="fa-clock" 
            color="green" 
          />
        </motion.div>
        
        {/* 练习记录列表 */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="space-y-4"
        >
          {records.length === 0 ? (
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-12 text-center border border-gray-100 dark:border-gray-700 shadow-sm">
              <i className="fas fa-file-alt text-gray-300 dark:text-gray-600 text-5xl mb-4"></i>
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">暂无练习记录</h3>
              <p className="text-gray-500 dark:text-gray-400">开始您的第一次FABE推销练习吧！</p>
            </div>
          ) : (
            records.map((record) => {
              const product = getProductById(record.productId);
              const customer = getCustomerById(record.customerId);
              
              return (
                <motion.div
                  key={record.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-md border border-gray-100 dark:border-gray-700 hover:shadow-lg transition-shadow"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                        {product?.name || '产品'}推销练习
                      </h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">
                        {formatDate(record.date)} • {formatDuration(record.duration)}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-3 mt-3 md:mt-0">
       {record.aiEvaluation && (
          <div className="flex items-center text-blue-400">
            {[...Array(5)].map((_, i) => (
              <i 
                key={i} 
                className={`fas fa-star ${i < Math.floor(record.aiEvaluation.overallScore) ? 'text-blue-400' : 'text-gray-300 dark:text-gray-600'}`}
                style={{ fontSize: '0.9rem' }}
              ></i>
            ))}
            <span className="ml-1 text-sm font-medium text-gray-700 dark:text-gray-300">
              {record.aiEvaluation.overallScore} (AI)
            </span>
          </div>
        )}
                      
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleEditRating(record)}
                          className="p-2 rounded-lg text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 transition-colors"
                          aria-label="编辑评价"
                        >
                          <i className="fas fa-edit"></i>
                        </button>
                        
                        <button
                          onClick={() => handleDeleteRecord(record.id)}
                          className="p-2 rounded-lg text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 transition-colors"
                          aria-label="删除记录"
                        >
                          <i className="fas fa-trash-alt"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  {/* 录音回放 */}
                  {record.recordingUrl && (
                    <div className="mt-3">
                      <audio controls src={record.recordingUrl} className="w-full">
                        您的浏览器不支持音频播放。
                      </audio>
                    </div>
                  )}
                  
       {/* AI评价分析 */}
      {record.aiEvaluation && (
        <div className="mt-4 space-y-3">
          <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg border border-blue-100 dark:border-blue-800">
            <h4 className="text-sm font-medium text-blue-600 dark:text-blue-400 mb-2 flex items-center">
              <i className="fas fa-robot mr-2"></i>
              AI评价
            </h4>
            
            {/* 维度评分 */}
            <div className="space-y-2 mb-3">
              {Object.entries(record.aiEvaluation.dimensionScores).map(([key, score]) => {
                const dimensionLabels: Record<string, string> = {
                  fabeStructure: 'FABE结构完整性',
                  languageFluency: '语言流畅度',
                  customerMatch: '客户需求匹配度',
                  persuasion: '说服力',
                  confidence: '自信度'
                };
                
                return (
                  <div key={key}>
                    <div className="flex justify-between mb-1">
                      <span className="text-xs font-medium text-gray-700 dark:text-gray-300">
                        {dimensionLabels[key]}
                      </span>
                      <span className="text-xs font-medium text-blue-500">{score}/5</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                      <div 
                        className="bg-blue-500 h-1.5 rounded-full" 
                        style={{ width: `${(score / 5) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
            
            {/* 优点 */}
            {record.aiEvaluation.strengths.length > 0 && (
              <div className="mb-2">
                <h5 className="text-xs font-medium text-green-600 dark:text-green-400 mb-1">优点</h5>
                <ul className="text-xs text-gray-700 dark:text-gray-300 space-y-1">
                  {record.aiEvaluation.strengths.map((strength, index) => (
                    <li key={index} className="flex items-start gap-1">
                      <i className="fas fa-thumbs-up text-green-500 mt-0.5 flex-shrink-0"></i>
                      <span>{strength}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            {/* 建议 */}
            {record.aiEvaluation.suggestions.length > 0 && (
              <div>
                <h5 className="text-xs font-medium text-blue-600 dark:text-blue-400 mb-1">建议</h5>
                <ul className="text-xs text-gray-700 dark:text-gray-300 space-y-1">
                  {record.aiEvaluation.suggestions.map((suggestion, index) => (
                    <li key={index} className="flex items-start gap-1">
                      <i className="fas fa-lightbulb text-yellow-500 mt-0.5 flex-shrink-0"></i>
                      <span>{suggestion}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}
                </motion.div>
              );
            })
          )}
        </motion.div>
      </main>
      
      {/* 导航栏 */}
      <NavBar />
      
      {/* 评价编辑模态框 */}
      {isRatingModalOpen && selectedRecord && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setIsRatingModalOpen(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">编辑评价</h2>
              <Rating
                initialScore={selectedRecord.score || 0}
                initialComments={selectedRecord.comments || ''}
                initialImprovementPoints={selectedRecord.improvementPoints || []}
                onSubmit={handleRatingUpdate}
              />
              <div className="mt-4 flex justify-end">
                <button
                  onClick={() => setIsRatingModalOpen(false)}
                  className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                >
                  取消
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}