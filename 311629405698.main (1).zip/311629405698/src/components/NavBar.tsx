import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';

interface NavBarProps {
  isMobile?: boolean;
}

export const NavBar: React.FC<NavBarProps> = ({ isMobile = true }) => {
  const location = useLocation();
  const [activeRoute, setActiveRoute] = useState(location.pathname);
  
  // 监听路由变化
  useEffect(() => {
    setActiveRoute(location.pathname);
  }, [location]);
  
  // 导航项配置
  const navItems = [
    {
      id: 'home',
      label: '首页',
      icon: 'fa-home',
      path: '/'
    },
    {
      id: 'practice',
      label: '开始练习',
      icon: 'fa-play-circle',
      path: '/practice'
    },
    {
      id: 'history',
      label: '练习记录',
      icon: 'fa-history',
      path: '/history'
    },
    {
      id: 'profile',
      label: '个人中心',
      icon: 'fa-user',
      path: '/profile'
    }
  ];
  
  // 移动端导航栏样式
  if (isMobile) {
    return (
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-50 shadow-[0_-2px_10px_rgba(0,0,0,0.05)] py-3 px-4"
      >
        <div className="flex justify-around items-center">
          {navItems.map((item) => (
            <Link
              key={item.id}
              to={item.path}
              className={`flex flex-col items-center justify-center px-3 py-2 ${
                activeRoute === item.path
                  ? 'text-blue-500'
                  : 'text-gray-500 dark:text-gray-400'
              }`}
            >
              <i className={`fas ${item.icon} text-xl mb-1`}></i>
              <span className="text-xs">{item.label}</span>
            </Link>
          ))}
        </div>
      </motion.div>
    );
  }
  
  // 桌面端导航栏样式
  return (
    <motion.div
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="fixed left-0 top-0 bottom-0 w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 z-50 shadow-lg hidden md:block"
    >
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <h1 className="text-2xl font-bold text-blue-500 flex items-center">
          <i className="fas fa-bullhorn mr-2"></i>
          FABE训练
        </h1>
      </div>
      
      <nav className="p-4">
        {navItems.map((item) => (
          <Link
            key={item.id}
            to={item.path}
            className={`flex items-center px-4 py-3 mb-2 rounded-lg transition-colors ${
              activeRoute === item.path
                ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-medium'
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
            }`}
          >
            <i className={`fas ${item.icon} text-lg w-6 text-center mr-3`}></i>
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>
    </motion.div>
  );
};