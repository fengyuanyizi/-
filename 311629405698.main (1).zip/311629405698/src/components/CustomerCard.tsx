import React from 'react';
import { Customer } from '../types';
import { motion } from 'framer-motion';

interface CustomerCardProps {
  customer: Customer;
}

export const CustomerCard: React.FC<CustomerCardProps> = ({ customer }) => {
  // 根据性格类型获取对应的颜色和图标
  const getPersonalityInfo = (personality: Customer['personality']) => {
    switch (personality) {
      case '谨慎型':
        return { color: 'blue', icon: 'fa-shield-alt', text: '谨慎型' };
      case '冲动型':
        return { color: 'red', icon: 'fa-bolt', text: '冲动型' };
      case '理智型':
        return { color: 'green', icon: 'fa-brain', text: '理智型' };
      case '情感型':
        return { color: 'purple', icon: 'fa-heart', text: '情感型' };
      default:
        return { color: 'gray', icon: 'fa-user', text: personality };
    }
  };

  const personalityInfo = getPersonalityInfo(customer.personality);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700"
    >
      <div className="flex items-center mb-6">
        {/* 客户头像占位符 */}
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-bold text-2xl mr-6">
          {customer.name.charAt(0)}
        </div>
        
        {/* 客户基本信息 */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{customer.name}</h2>
          <div className="flex items-center text-gray-600 dark:text-gray-300 mb-2">
            <span>{customer.age}岁</span>
            <span className="mx-2">|</span>
            <span>{customer.occupation}</span>
          </div>
          <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-${personalityInfo.color}-100 text-${personalityInfo.color}-600 dark:bg-${personalityInfo.color}-900 dark:text-${personalityInfo.color}-300`}>
            <i className={`fas ${personalityInfo.icon} mr-1`}></i>
            {personalityInfo.text}
          </div>
        </div>
      </div>
      
      {/* 客户详细信息 */}
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2 flex items-center">
            <i className="fas fa-bullseye text-blue-500 mr-2"></i>
            需求
          </h3>
          <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 pl-4 space-y-1">
            {customer.needs.map((need, index) => (
              <li key={index}>{need}</li>
            ))}
          </ul>
        </div>
        
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2 flex items-center">
            <i className="fas fa-thumbs-up text-green-500 mr-2"></i>
            偏好
          </h3>
          <div className="flex flex-wrap gap-2">
            {customer.preferences.map((preference, index) => (
              <span 
                key={index} 
                className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300"
              >
                {preference}
              </span>
            ))}
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2 flex items-center">
            <i className="fas fa-exclamation-triangle text-yellow-500 mr-2"></i>
            顾虑
          </h3>
          <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 pl-4 space-y-1">
            {customer.concerns.map((concern, index) => (
              <li key={index}>{concern}</li>
            ))}
          </ul>
        </div>
      </div>
    </motion.div>
  );
};