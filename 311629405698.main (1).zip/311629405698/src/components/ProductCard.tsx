import React from 'react';
import { Product } from '../types';
import { motion } from 'framer-motion';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 mb-6 overflow-hidden border border-gray-100 dark:border-gray-700"
    >
      <div className="flex flex-col md:flex-row gap-6">
        {/* 产品图片 */}
        <div className="md:w-1/3 flex-shrink-0">
          <div className="rounded-xl overflow-hidden bg-gray-100 dark:bg-gray-700 aspect-square">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
        
        {/* 产品信息 */}
        <div className="md:w-2/3">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{product.name}</h2>
          <p className="text-sm text-blue-500 mb-4">{product.category}</p>
          <p className="text-2xl font-bold text-red-500 mb-6">¥{product.price}</p>
          
          {/* FABE 特性 */}
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-1">
                <span className="inline-block w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 text-xs font-bold flex items-center justify-center mr-2">F</span>
                特征
              </h3>
              <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 pl-8 space-y-1">
                {product.features.map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-1">
                <span className="inline-block w-6 h-6 rounded-full bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300 text-xs font-bold flex items-center justify-center mr-2">A</span>
                优势
              </h3>
              <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 pl-8 space-y-1">
                {product.advantages.map((advantage, index) => (
                  <li key={index}>{advantage}</li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-1">
                <span className="inline-block w-6 h-6 rounded-full bg-yellow-100 dark:bg-yellow-900 text-yellow-600 dark:text-yellow-300 text-xs font-bold flex items-center justify-center mr-2">B</span>
                利益
              </h3>
              <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 pl-8 space-y-1">
                {product.benefits.map((benefit, index) => (
                  <li key={index}>{benefit}</li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-1">
                <span className="inline-block w-6 h-6 rounded-full bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-300 text-xs font-bold flex items-center justify-center mr-2">E</span>
                证据
              </h3>
              <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 pl-8 space-y-1">
                {product.evidence.map((evidence, index) => (
                  <li key={index}>{evidence}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};