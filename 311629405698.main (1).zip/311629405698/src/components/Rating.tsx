import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

interface RatingProps {
  onSubmit: (score: number, comments: string, improvementPoints: string[]) => void;
  initialScore?: number;
  initialComments?: string;
  initialImprovementPoints?: string[];
  disabled?: boolean;
}

export const Rating: React.FC<RatingProps> = ({ 
  onSubmit, 
  initialScore = 0, 
  initialComments = '', 
  initialImprovementPoints = [],
  disabled = false
}) => {
  const [score, setScore] = useState(initialScore);
  const [comments, setComments] = useState(initialComments);
  const [improvementPoints, setImprovementPoints] = useState(initialImprovementPoints);
  const [newImprovementPoint, setNewImprovementPoint] = useState('');
  
  // 添加改进点
  const handleAddImprovementPoint = () => {
    if (newImprovementPoint.trim() && !improvementPoints.includes(newImprovementPoint.trim())) {
      setImprovementPoints([...improvementPoints, newImprovementPoint.trim()]);
      setNewImprovementPoint('');
    }
  };
  
  // 删除改进点
  const handleRemoveImprovementPoint = (pointToRemove: string) => {
    setImprovementPoints(improvementPoints.filter(point => point !== pointToRemove));
  };
  
  // 处理提交
  const handleSubmit = () => {
    if (score === 0) {
      toast.warning('请先给出评分');
      return;
    }
    
    onSubmit(score, comments, improvementPoints);
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700"
    >
      <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">练习评价</h2>
      
      {/* 评分区域 */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3">评分</h3>
        <div className="flex items-center gap-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              disabled={disabled}
              onClick={() => !disabled && setScore(star)}
              className={`text-3xl ${
                star <= score 
                  ? 'text-yellow-400' 
                  : 'text-gray-300 dark:text-gray-600'
              } transition-colors`}
            >
              <i className="fas fa-star"></i>
            </button>
          ))}
          <span className="ml-2 text-lg font-semibold text-gray-700 dark:text-gray-300">
            {score}/5
          </span>
        </div>
      </div>
      
      {/* 评价区域 */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3">评价与建议</h3>
        <textarea
          value={comments}
          onChange={(e) => !disabled && setComments(e.target.value)}
          disabled={disabled}
          placeholder="请输入您的评价和建议..."
          className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all resize-none h-32"
        ></textarea>
      </div>
      
      {/* 改进点区域 */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3">改进点</h3>
        <div className="flex gap-2 mb-3">
          <input
            type="text"
            value={newImprovementPoint}
            onChange={(e) => !disabled && setNewImprovementPoint(e.target.value)}
            disabled={disabled}
            placeholder="输入改进点..."
            className="flex-1 p-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
          <button
            onClick={handleAddImprovementPoint}
            disabled={disabled || !newImprovementPoint.trim()}
            className={`px-4 py-2 rounded-lg ${
              disabled || !newImprovementPoint.trim()
                ? 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                : 'bg-blue-500 hover:bg-blue-600 text-white transition-colors'
            }`}
          >
            添加
          </button>
        </div>
        
        {/* 已添加的改进点 */}
        <div className="flex flex-wrap gap-2">
          {improvementPoints.map((point, index) => (
            <div
              key={index}
              className="flex items-center gap-2 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 px-3 py-1 rounded-full text-sm"
            >
              <span>{point}</span>
              {!disabled && (
                <button
                  onClick={() => handleRemoveImprovementPoint(point)}
                  className="text-blue-500 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-200"
                >
                  <i className="fas fa-times"></i>
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
      
      {/* 提交按钮 */}
      <button
        onClick={handleSubmit}
        disabled={disabled}
        className={`w-full py-3 rounded-lg font-medium ${
          disabled
            ? 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'
            : 'bg-green-500 hover:bg-green-600 text-white transition-colors'
        }`}
      >
        提交评价
      </button>
    </motion.div>
  );
};