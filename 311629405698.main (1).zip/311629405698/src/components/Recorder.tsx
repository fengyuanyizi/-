import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

interface RecorderProps {
  onRecordingComplete: (blob: Blob, duration: number) => void;
}

export const Recorder: React.FC<RecorderProps> = ({ onRecordingComplete }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioChunks, setAudioChunks] = useState<Blob[]>([]);
  const [isPermissionGranted, setIsPermissionGranted] = useState<boolean | null>(null);
  const timerRef = useRef<number | null>(null);
  
  // 请求麦克风权限
  useEffect(() => {
    const requestPermission = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach(track => track.stop());
        setIsPermissionGranted(true);
      } catch (error) {
        console.error('无法访问麦克风:', error);
        setIsPermissionGranted(false);
        toast.error('无法访问麦克风，请检查您的浏览器权限设置。');
      }
    };
    
    requestPermission();
  }, []);
  
  // 格式化时间显示
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // 开始录制
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          setAudioChunks(prev => [...prev, event.data]);
        }
      };
      
      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        onRecordingComplete(audioBlob, recordingTime);
        setAudioChunks([]);
      };
      
      setMediaRecorder(recorder);
      setIsRecording(true);
      setRecordingTime(0);
      
      // 开始计时器
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      
      recorder.start();
    } catch (error) {
      console.error('开始录制失败:', error);
      toast.error('开始录制失败，请重试。');
    }
  };
  
  // 停止录制
  const stopRecording = () => {
    if (mediaRecorder) {
      mediaRecorder.stop();
      mediaRecorder.stream.getTracks().forEach(track => track.stop());
    }
    
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    
    setIsRecording(false);
  };
  
  // 组件卸载时清理计时器
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);
  
  // 当权限未授予时显示的内容
  if (isPermissionGranted === false) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 text-center border border-gray-100 dark:border-gray-700">
        <div className="text-yellow-500 text-5xl mb-4">
          <i className="fas fa-exclamation-circle"></i>
        </div>
        <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">需要麦克风权限</h3>
        <p className="text-gray-600 dark:text-gray-300 mb-4">
          请在浏览器设置中允许此网站访问您的麦克风，以便进行录音练习。
        </p>
        <button 
          onClick={() => window.location.reload()}
          className="px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-full transition-colors"
        >
          重试
        </button>
      </div>
    );
  }
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700"
    >
      <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6 text-center">练习录制</h2>
      
      <div className="flex flex-col items-center justify-center">
        {/* 录制时间显示 */}
        <AnimatePresence>
          {isRecording && (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="mb-6 text-3xl font-mono font-bold text-red-500"
            >
              {formatTime(recordingTime)}
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* 录制按钮 */}
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={isRecording ? stopRecording : startRecording}
          className={`w-24 h-24 rounded-full flex items-center justify-center text-white text-xl ${
            isRecording 
              ? 'bg-red-500 hover:bg-red-600' 
              : 'bg-green-500 hover:bg-green-600'
          } transition-colors shadow-lg`}
        >
          {isRecording ? (
            <i className="fas fa-stop"></i>
          ) : (
            <i className="fas fa-microphone"></i>
          )}
        </motion.button>
        
        {/* 录制状态提示 */}
        <p className={`mt-4 text-sm ${
          isRecording 
            ? 'text-red-500' 
            : 'text-gray-500 dark:text-gray-400'
        }`}>
          {isRecording 
            ? '正在录制，请开始您的推销练习...' 
            : '点击按钮开始录制'
          }
        </p>
      </div>
    </motion.div>
  );
};