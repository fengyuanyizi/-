// FABE推销训练平台类型定义

// 产品信息类型
export interface Product {
  id: string;
  name: string;
  category: string;
  features: string[]; // 特征
  advantages: string[]; // 优势
  benefits: string[]; // 利益
  evidence: string[]; // 证据
  price: number;
  image: string;
}

// 客户信息类型
export interface Customer {
  id: string;
  name: string;
  age: number;
  occupation: string;
  needs: string[];
  preferences: string[];
  concerns: string[];
  personality: '谨慎型' | '冲动型' | '理智型' | '情感型';
}

// 练习记录类型
export interface PracticeRecord {
  id: string;
  date: string;
  productId: string;
  customerId: string;
  recordingUrl?: string;
  duration: number; // 录制时长（秒）
  aiEvaluation?: AIEvaluation; // AI评价
}

// FABE话术类型
export interface FABEAnswer {
  feature: string;
  advantage: string;
  benefit: string;
  evidence: string;
}

// AI评价类型
export interface AIEvaluation {
  overallScore: number; // 总评分
  dimensionScores: {
    fabeStructure: number; // FABE结构完整性
    languageFluency: number; // 语言流畅度
    customerMatch: number; // 客户需求匹配度
    persuasion: number; // 说服力
    confidence: number; // 自信度
  };
  suggestions: string[]; // 建议
  strengths: string[]; // 优点
}

// 评价维度类型
export interface EvaluationDimension {
  name: string;
  description: string;
  maxScore: number;
}

// 优秀话术示例类型
export interface ExcellentScript {
  id: string;
  productId: string;
  customerTypeId: string; // 对应客户类型ID
  script: string; // 完整话术
  fabeBreakdown: {
    feature: string;
    advantage: string;
    benefit: string;
    evidence: string;
  };
  tips: string[]; // 话术技巧提示
}